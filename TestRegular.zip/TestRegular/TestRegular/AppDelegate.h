//
//  AppDelegate.h
//  TestRegular
//
//  Created by 94bank on 14-11-4.
//  Copyright (c) 2014年 统领得一网络科技（上海）有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
