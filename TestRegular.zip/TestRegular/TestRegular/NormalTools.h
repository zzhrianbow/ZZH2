//
//  NormalTools.h
//  TestRegular
//
//  Created by 94bank on 14-11-4.
//  Copyright (c) 2014年 统领得一网络科技（上海）有限公司. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NormalTools : NSObject
//验证正数
+ (BOOL)verify_PositiveNumber_Formater:(NSString *)testStr;

//验证邮箱
+ (BOOL)verify_Email_Formater:(NSString *)testStr;

//汉子匹配
+ (BOOL)verify_Word_Formater:(NSString *)testStr;
@end
