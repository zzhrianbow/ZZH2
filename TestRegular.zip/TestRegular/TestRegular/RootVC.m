//
//  RootVC.m
//  TestRegular
//
//  Created by 94bank on 14-11-4.
//  Copyright (c) 2014年 统领得一网络科技（上海）有限公司. All rights reserved.
//

#import "RootVC.h"
#import "NormalTools.h"
@interface RootVC (){
    UITextField *inputView;
    UILabel *outputView;
}

@end

@implementation RootVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)loadView
{
    UIView *aview = [[UIView alloc]init];
    aview.frame = [[UIScreen mainScreen]bounds];
    self.view = aview;
}

#define  SCREEN_WIDTH   [[UIScreen mainScreen]bounds].size.width
- (void)viewDidLoad
{
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    inputView = [[UITextField alloc]init];
    inputView.frame = CGRectMake((SCREEN_WIDTH - 200)/2, 30, 200, 30);
    inputView.backgroundColor = [UIColor lightGrayColor];
    inputView.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    inputView.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:inputView];
    
    outputView = [[UILabel alloc]init];
    outputView.frame = CGRectMake((SCREEN_WIDTH - 100)/2, inputView.frame.origin.y + inputView.frame.size.height + 5, 100, 25);
    outputView.backgroundColor = [UIColor grayColor];
    outputView.textAlignment = NSTextAlignmentCenter;
    outputView.textColor = [UIColor redColor];
    [self.view addSubview:outputView];
    
    UIButton *doneBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    doneBtn.frame = CGRectMake((SCREEN_WIDTH - 60)/2, outputView.frame.origin.y + outputView.frame.size.height + 10, 60, 30);
    [doneBtn setTitle:@"done" forState:UIControlStateNormal];
    [doneBtn setBackgroundColor:[UIColor greenColor]];
    doneBtn.layer.cornerRadius = 5.0;
    [doneBtn addTarget:self action:@selector(judgeTheString:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:doneBtn];
    
    
    
    
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




#pragma mark- user method

- (void)judgeTheString:(UIButton *)sender
{

    outputView.text = @"";
    
    NSString *inputStr = inputView.text;
    if (!inputStr || inputStr.length == 0) {
        return;
    }
    
    if ([NormalTools verify_Word_Formater:inputStr]) {
        outputView.text = @"yes";
    }else{
        outputView.text = @"no";
    }
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
