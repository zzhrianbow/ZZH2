//
//  NormalTools.m
//  TestRegular
//
//  Created by 94bank on 14-11-4.
//  Copyright (c) 2014年 统领得一网络科技（上海）有限公司. All rights reserved.
//

#import "NormalTools.h"

@implementation NormalTools

//验证正数
+ (BOOL)verify_PositiveNumber_Formater:(NSString *)testStr{
    NSString * regex = @"^[0-9]*(\\.[0-9]*)?$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    BOOL isMatch = [pred evaluateWithObject:testStr];
    return isMatch; 
}


//验证邮箱
+ (BOOL)verify_Email_Formater:(NSString *)testStr{
    NSString * regex = @"^([\\w_\\-])+@(\\w)+(\\.)(\\w){1,3}$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    BOOL isMatch = [pred evaluateWithObject:testStr];
    return isMatch;
    return YES;
}

//简繁体汉字匹配
+ (BOOL)verify_Word_Formater:(NSString *)testStr{
//    NSString * regex = @".+";
    NSString * regex = @"^[\u4E00-\u9FFF]+$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    BOOL isMatch = [pred evaluateWithObject:testStr];
    NSLog(@"string is %@",[pred predicateFormat]);
    return isMatch;
}
@end
